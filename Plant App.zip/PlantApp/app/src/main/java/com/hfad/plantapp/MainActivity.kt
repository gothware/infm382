package com.hfad.plantapp

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.hfad.plantapp.ui.login.LoginActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var plantButton1 = findViewById<Button>(R.id.plantButton)
        plantButton1.setOnClickListener { startActivity(Intent(this, PlantEditor::class.java)) }

        var plantButton2 = findViewById<Button>(R.id.plantButton2)
        plantButton2.setOnClickListener { startActivity(Intent(this, PlantEditor2::class.java)) }

        var plantButton3 = findViewById<Button>(R.id.plantButton3)
        plantButton3.setOnClickListener { startActivity(Intent(this, PlantEditor3::class.java)) }

        var plantButton4 = findViewById<Button>(R.id.plantButton4)
        plantButton4.setOnClickListener { startActivity(Intent(this, PlantEditor4::class.java)) }

        var plantButton5 = findViewById<Button>(R.id.plantButton5)
        plantButton5.setOnClickListener { startActivity(Intent(this, PlantEditor5::class.java)) }
    }




    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle item selection
        return when (item.itemId) {
            R.id.plantLib -> {
                startActivity(Intent(this, MainActivity::class.java))
                true
            }
            R.id.cal -> {
                startActivity(Intent(this, Calendar::class.java))
                true
            }
            R.id.acc -> {
                startActivity(Intent(this, LoginActivity::class.java))
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}